sql
CREATE INDEX email_index ON users(email);

SELECT orders.id, customers.name
FROM orders
JOIN customers ON orders.customer_id = customers.id;
