<?php
require 'vendor/autoload.php';

// Connect to Redis server
$redis = new Predis\Client();

// Check if data is cached in Redis
$cacheKey = 'user_data';
$userData = $redis->get($cacheKey);

if ($userData === null) {
    // Data not in cache, fetch from database
    $userData = getUserDataFromDatabase();
    $redis->set($cacheKey, json_encode($userData)); // Cache data in Redis
    $redis->expire($cacheKey, 3600); // Cache expires in 1 hour
}

echo $userData;
?>