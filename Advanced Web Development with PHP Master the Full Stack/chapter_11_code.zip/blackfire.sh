bash
blackfire run --sample=10 --output=profile.html
