<?php
// Connect to Memcached server
$memcached = new Memcached();
$memcached->addServer('127.0.0.1', 11211);

// Try to fetch data from the cache
$cacheKey = 'product_data';
$productData = $memcached->get($cacheKey);

if ($productData === false) {
    // Data not in cache, fetch from database
    $productData = getProductDataFromDatabase(); // Fetch data from DB
    $memcached->set($cacheKey, $productData, 3600); // Cache for 1 hour
}

echo json_encode($productData);
?>