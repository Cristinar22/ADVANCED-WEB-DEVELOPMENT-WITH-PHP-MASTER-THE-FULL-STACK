<?php
session_start();
include('db.php');

echo "<h2>Your Cart</h2>";

if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    foreach ($_SESSION['cart'] as $product_id => $quantity) {
        $sql = "SELECT * FROM products WHERE id = $product_id";
        $result = $conn->query($sql);
        $product = $result->fetch_assoc();

        echo "<div class='cart-item'>
                <h3>" . $product['name'] . "</h3>
                <p>Quantity: $quantity</p>
                <p>Price: $" . ($product['price'] * $quantity) . "</p>
              </div>";
    }
} else {
    echo "Your cart is empty.";
}

$conn->close();
?>