<?php
include('db.php');

$sql = "SELECT * FROM products";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='product-item'>
                <img src='" . $row['image_url'] . "' alt='" . $row['name'] . "'>
                <h2>" . $row['name'] . "</h2>
                <p>" . $row['description'] . "</p>
                <p>$" . $row['price'] . "</p>
                <button>Add to Cart</button>
              </div>";
    }
} else {
    echo "No products found.";
}

$conn->close();
?>