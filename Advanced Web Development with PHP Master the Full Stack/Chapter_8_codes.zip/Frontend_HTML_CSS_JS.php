<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listing</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="product-container">
        <div class="product-item">
            <img src="product1.jpg" alt="Product 1">
            <h2>Product 1</h2>
            <p>$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="product-item">
            <img src="product2.jpg" alt="Product 2">
            <h2>Product 2</h2>
            <p>$29.99</p>
            <button>Add to Cart</button>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>