<?php
// public/index.php
require_once('../config/database.php');
require_once('../app/controllers/PostController.php');

$controller = new PostController($pdo);

if (isset($_GET['action']) && $_GET['action'] == 'view' && isset($_GET['id'])) {
    $controller->viewPost($_GET['id']);
} else {
    $controller->listPosts();
}
?>