<?php
// app/controllers/PostController.php
require_once('../models/Post.php');

class PostController {
    private $postModel;

    public function __construct($pdo) {
        $this->postModel = new Post($pdo);
    }

    public function listPosts() {
        $posts = $this->postModel->getAllPosts();
        require_once('../views/postList.php');
    }

    public function viewPost($id) {
        $post = $this->postModel->getPostById($id);
        require_once('../views/postDetail.php');
    }
}
?>