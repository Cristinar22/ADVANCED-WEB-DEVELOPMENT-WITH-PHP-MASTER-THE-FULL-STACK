<?php
// app/views/postList.php
echo "<h1>Blog Posts</h1>";

foreach ($posts as $post) {
    echo "<h2><a href='?action=view&id=" . $post['id'] . "'>" . $post['title'] . "</a></h2>";
    echo "<p>" . substr($post['content'], 0, 100) . "...</p>";
    echo "<hr>";
}
?>