<?php
// app/views/postDetail.php
echo "<h1>" . $post['title'] . "</h1>";
echo "<p>" . $post['content'] . "</p>";
echo "<hr>";
?>