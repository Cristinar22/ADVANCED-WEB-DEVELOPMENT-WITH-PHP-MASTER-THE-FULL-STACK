<?php
  $colors = ["red", "green", "blue"];
  echo $colors[0];  // Outputs: red

  $person = [
    "name" => "Alice",
    "age" => 30,
    "city" => "New York"
  ];
  echo $person["name"];  // Outputs: Alice
?>