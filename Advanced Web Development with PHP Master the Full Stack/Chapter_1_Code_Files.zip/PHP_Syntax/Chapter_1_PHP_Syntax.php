<?php
  // This is a single-line comment
  echo "Hello, World!";
?>