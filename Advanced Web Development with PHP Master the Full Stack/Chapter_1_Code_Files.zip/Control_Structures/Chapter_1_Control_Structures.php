<?php
  $age = 20;
  if ($age >= 18) {
    echo "You are an adult!";
  } else {
    echo "You are a minor.";
  }

  $score = 85;
  if ($score >= 90) {
    echo "Grade: A";
  } elseif ($score >= 80) {
    echo "Grade: B";
  } else {
    echo "Grade: C";
  }
?>