<?php
  $birth_year = 1995;
  $current_year = date("Y");
  $age = $current_year - $birth_year;
  echo "You are $age years old.";
?>