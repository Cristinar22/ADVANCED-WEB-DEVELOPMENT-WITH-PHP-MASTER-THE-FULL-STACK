<?php
  $name = "Alice";  // string variable
  $age = 30;        // integer variable
?>