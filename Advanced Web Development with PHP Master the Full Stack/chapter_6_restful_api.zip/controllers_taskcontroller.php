
<?php
// app/controllers/TaskController.php
require_once('../models/Task.php');

class TaskController {
    private $taskModel;

    public function __construct($pdo) {
        $this->taskModel = new Task($pdo);
    }

    // GET /tasks
    public function getTasks() {
        $tasks = $this->taskModel->getAllTasks();
        echo json_encode($tasks);
    }

    // GET /tasks/{id}
    public function getTask($id) {
        $task = $this->taskModel->getTaskById($id);
        echo json_encode($task);
    }

    // POST /tasks
    public function createTask() {
        $data = json_decode(file_get_contents("php://input"));
        $this->taskModel->createTask($data->title, $data->description);
        echo json_encode(["message" => "Task created successfully"]);
    }

    // PUT /tasks/{id}
    public function updateTask($id) {
        $data = json_decode(file_get_contents("php://input"));
        $this->taskModel->updateTask($id, $data->title, $data->description, $data->status);
        echo json_encode(["message" => "Task updated successfully"]);
    }

    // DELETE /tasks/{id}
    public function deleteTask($id) {
        $this->taskModel->deleteTask($id);
        echo json_encode(["message" => "Task deleted successfully"]);
    }
}
?>
    