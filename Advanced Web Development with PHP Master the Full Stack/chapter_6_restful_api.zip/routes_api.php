
<?php
// app/routes/api.php
require_once('../controllers/TaskController.php');

$controller = new TaskController($pdo);

// Define routes
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {
        $controller->getTask($_GET['id']);  // GET /tasks/{id}
    } else {
        $controller->getTasks();  // GET /tasks
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $controller->createTask();  // POST /tasks
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT' && isset($_GET['id'])) {
    $controller->updateTask($_GET['id']);  // PUT /tasks/{id}
} elseif ($_SERVER['REQUEST_METHOD'] == 'DELETE' && isset($_GET['id'])) {
    $controller->deleteTask($_GET['id']);  // DELETE /tasks/{id}
}
?>
    