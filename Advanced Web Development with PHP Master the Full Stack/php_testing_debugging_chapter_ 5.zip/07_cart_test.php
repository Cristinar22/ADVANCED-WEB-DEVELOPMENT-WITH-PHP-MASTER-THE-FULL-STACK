<?php
    // PHPUnit tests for the Cart class
    use PHPUnit\Framework\TestCase;
    use App\Product;
    use App\Cart;
    class CartTest extends TestCase {
        public function testAddProduct() {
            $cart = new Cart();
            $product = new Product("Laptop", 1000);
            $cart->addProduct($product);
            $this->assertCount(1, $cart->getItems());
        }
        public function testGetTotalPrice() {
            $cart = new Cart();
            $product1 = new Product("Laptop", 1000);
            $product2 = new Product("Phone", 500);
            $cart->addProduct($product1);
            $cart->addProduct($product2);
            $this->assertEquals(1500, $cart->getTotalPrice());
        }
    }
    ?>