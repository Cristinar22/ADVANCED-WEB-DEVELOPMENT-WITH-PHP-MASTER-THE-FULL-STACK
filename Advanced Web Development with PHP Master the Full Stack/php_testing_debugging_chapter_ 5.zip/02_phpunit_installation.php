<?php
    // Step-by-step instructions for installing PHPUnit via Composer
    echo "Installing PHPUnit using Composer";
    ?>