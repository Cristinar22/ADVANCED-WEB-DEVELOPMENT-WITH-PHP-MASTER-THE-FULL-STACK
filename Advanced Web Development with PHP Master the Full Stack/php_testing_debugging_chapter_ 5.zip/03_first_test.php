<?php
    // First test to check the add function
    use PHPUnit\Framework\TestCase;
    use App\Math;
    class MathTest extends TestCase {
        public function testAdd() {
            $math = new Math();
            $this->assertEquals(5, $math->add(2, 3)); 
            $this->assertEquals(0, $math->add(-2, 2)); 
            $this->assertEquals(-5, $math->add(-2, -3)); 
        }
    }
    ?>