<?php
    // Cart class for handling products in the cart
    namespace App;
    class Cart {
        private $items = [];
        public function addProduct(Product $product) {
            $this->items[] = $product;
        }
        public function getTotalPrice() {
            $total = 0;
            foreach ($this->items as $item) {
                $total += $item->getPrice();
            }
            return $total;
        }
        public function getItems() {
            return $this->items;
        }
    }
    ?>