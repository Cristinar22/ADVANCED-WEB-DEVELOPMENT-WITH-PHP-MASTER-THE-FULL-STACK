<?php
class Book {
    private $title;
    private $author;
    private $isAvailable;

    public function __construct($title, $author) {
        $this->title = $title;
        $this->author = $author;
        $this->isAvailable = true;
    }

    public function getTitle() {
        return $this->title;
    }

    public function getAuthor() {
        return $this->author;
    }

    public function isAvailable() {
        return $this->isAvailable;
    }

    public function checkOut() {
        if ($this->isAvailable) {
            $this->isAvailable = false;
            echo "The book "" . $this->getTitle() . "" has been checked out.";
        } else {
            echo "Sorry, the book "" . $this->getTitle() . "" is not available.";
        }
    }

    public function returnBook() {
        $this->isAvailable = true;
        echo "The book "" . $this->getTitle() . "" has been returned.";
    }
}

class Library {
    private $books = [];

    public function addBook($book) {
        $this->books[] = $book;
    }

    public function listAvailableBooks() {
        echo "Available books in the library: <br>";
        foreach ($this->books as $book) {
            if ($book->isAvailable()) {
                echo $book->getTitle() . " by " . $book->getAuthor() . "<br>";
            }
        }
    }
}

$library = new Library();

$book1 = new Book("1984", "George Orwell");
$book2 = new Book("The Catcher in the Rye", "J.D. Salinger");

$library->addBook($book1);
$library->addBook($book2);

$library->listAvailableBooks();
?>