<?php
// Define a class called Car
class Car {
    public $color;
    public $model;
    public $engineType;

    public function startEngine() {
        echo "The engine is now running.";
    }
}

$myCar = new Car();
$myCar->color = "Red";
$myCar->model = "Tesla Model S";
$myCar->engineType = "Electric";

echo "My car is a " . $myCar->color . " " . $myCar->model . " with a " . $myCar->engineType . " engine.";
$myCar->startEngine();
?>