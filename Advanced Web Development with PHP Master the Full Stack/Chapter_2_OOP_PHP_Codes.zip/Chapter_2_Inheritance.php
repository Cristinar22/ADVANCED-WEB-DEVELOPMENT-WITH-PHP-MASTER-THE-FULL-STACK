<?php
class Animal {
    public $name;

    public function __construct($name) {
        $this->name = $name;
    }

    public function speak() {
        echo "$this->name makes a sound.";
    }
}

class Dog extends Animal {
    public function speak() {
        echo "$this->name barks.";
    }
}

$dog = new Dog("Rex");
$dog->speak();  // Outputs: Rex barks.
?>