<?php
class Shape {
    public function draw() {
        echo "Drawing a shape.";
    }
}

class Circle extends Shape {
    public function draw() {
        echo "Drawing a circle.";
    }
}

class Square extends Shape {
    public function draw() {
        echo "Drawing a square.";
    }
}

function displayDrawing(Shape $shape) {
    $shape->draw();
}

$circle = new Circle();
$square = new Square();

displayDrawing($circle);  // Outputs: Drawing a circle.
displayDrawing($square);  // Outputs: Drawing a square.
?>