<?php
class BankAccount {
    private $balance;

    public function __construct($initialBalance) {
        $this->balance = $initialBalance;
    }

    public function getBalance() {
        return $this->balance;
    }

    public function deposit($amount) {
        if ($amount > 0) {
            $this->balance += $amount;
        }
    }

    private function calculateInterest() {
        return $this->balance * 0.02;
    }
}

$account = new BankAccount(1000);
$account->deposit(500);
echo $account->getBalance();
?>