<?php
// Generate token when the form is created
$token = bin2hex(random_bytes(32));
$_SESSION['token'] = $token;

// Add token to the form
echo '<form method="POST">';
echo '<input type="hidden" name="token" value="' . $token . '">';
echo '</form>';
?>