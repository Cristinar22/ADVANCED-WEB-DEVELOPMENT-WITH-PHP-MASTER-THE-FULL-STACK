<?php
// Validate email
if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    echo "Valid email.";
} else {
    echo "Invalid email.";
}
?>