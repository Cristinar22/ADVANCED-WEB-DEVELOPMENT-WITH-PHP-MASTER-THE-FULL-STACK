<?php
echo "Hello, " . $_GET['name'] . "!";
?>