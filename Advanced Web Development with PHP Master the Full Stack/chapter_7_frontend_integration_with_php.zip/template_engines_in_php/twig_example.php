<?php
require_once '/path/to/vendor/autoload.php';

// Initialize Twig
$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);

// Render a template
echo $twig->render('index.twig', ['name' => 'John Doe']);
?>