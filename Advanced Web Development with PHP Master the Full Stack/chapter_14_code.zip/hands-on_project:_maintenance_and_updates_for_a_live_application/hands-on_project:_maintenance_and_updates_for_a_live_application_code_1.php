# Git pull for updates
git pull origin main
composer install
php artisan migrate
