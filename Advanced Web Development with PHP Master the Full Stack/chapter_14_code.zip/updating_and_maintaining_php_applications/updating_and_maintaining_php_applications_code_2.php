# Git deployment example
git pull origin main
composer install
php artisan migrate
