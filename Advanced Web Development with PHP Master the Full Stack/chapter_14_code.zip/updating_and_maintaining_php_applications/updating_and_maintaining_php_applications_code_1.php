# Update PHP on a server
sudo apt-get update
sudo apt-get install php7.4
