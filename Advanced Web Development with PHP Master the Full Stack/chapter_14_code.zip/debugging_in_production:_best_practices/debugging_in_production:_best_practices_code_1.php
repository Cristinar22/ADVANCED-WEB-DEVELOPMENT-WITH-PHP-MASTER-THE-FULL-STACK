# Disable error display in production
ini_set('display_errors', 0);
error_reporting(E_ALL);
