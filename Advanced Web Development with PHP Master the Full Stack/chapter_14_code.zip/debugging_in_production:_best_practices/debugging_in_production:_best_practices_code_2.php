# Xdebug remote debugging setup
xdebug.remote_enable = 1
xdebug.remote_host = 'localhost'
xdebug.remote_port = 9000
