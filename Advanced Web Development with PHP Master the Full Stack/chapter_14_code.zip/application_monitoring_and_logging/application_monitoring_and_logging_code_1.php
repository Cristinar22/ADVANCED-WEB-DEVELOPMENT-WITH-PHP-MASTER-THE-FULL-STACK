# Install New Relic on the server
sudo apt install newrelic-php5
