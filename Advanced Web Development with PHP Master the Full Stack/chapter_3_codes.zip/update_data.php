<?php
// Prepare the SQL query
$stmt = $conn->prepare("UPDATE users SET email = :email WHERE name = :name");

// Bind the parameters
$stmt->bindParam(':email', $email);
$stmt->bindParam(':name', $name);

// Set values for the variables
$email = "john.doe@newdomain.com";
$name = "John Doe";

// Execute the update
$stmt->execute();

echo "Record updated successfully!";
?>