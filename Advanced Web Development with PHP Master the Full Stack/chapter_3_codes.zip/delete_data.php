<?php
// Prepare the SQL query
$stmt = $conn->prepare("DELETE FROM users WHERE name = :name");

// Bind the parameter
$stmt->bindParam(':name', $name);

// Set the value for the parameter
$name = "John Doe";

// Execute the deletion
$stmt->execute();

echo "Record deleted successfully!";
?>