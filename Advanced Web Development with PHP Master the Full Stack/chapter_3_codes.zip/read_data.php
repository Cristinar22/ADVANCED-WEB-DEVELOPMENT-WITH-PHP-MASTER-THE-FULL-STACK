<?php
// Prepare the SQL query
$stmt = $conn->prepare("SELECT id, name, email FROM users");

// Execute the query
$stmt->execute();

// Fetch all the results as an associative array
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Loop through the results and display them
foreach ($results as $row) {
    echo "ID: " . $row['id'] . " - Name: " . $row['name'] . " - Email: " . $row['email'] . "<br>";
}
?>