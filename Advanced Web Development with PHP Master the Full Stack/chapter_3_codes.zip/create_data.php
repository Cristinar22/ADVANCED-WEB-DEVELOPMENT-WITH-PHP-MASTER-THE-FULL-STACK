<?php
// Prepare an SQL statement
$stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (:name, :email, :password)");

// Bind parameters to the SQL statement
$stmt->bindParam(':name', $name);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':password', $password);

// Set values for the variables
$name = "John Doe";
$email = "john.doe@example.com";
$password = "password123";

// Execute the statement
$stmt->execute();

echo "New record created successfully!";
?>