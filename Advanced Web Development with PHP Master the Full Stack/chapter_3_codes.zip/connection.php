<?php
$servername = "localhost"; // Server name
$username = "root";        // MySQL username (default is 'root')
$password = "";            // MySQL password (default is empty)
$dbname = "my_database";   // The database name

try {
    // Create a PDO instance (connect to MySQL)
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Connected successfully";
}
catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>