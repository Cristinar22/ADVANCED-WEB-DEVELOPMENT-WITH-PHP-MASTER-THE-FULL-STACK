
    # Connecting to Server via SSH
    ssh username@your-server-ip
    # Uploading files via SCP
    scp -r /path/to/your/local/project username@your-server-ip:/path/to/remote/directory
    