
    # Enabling OPCache
    opcache.enable=1
    opcache.memory_consumption=128
    # Database Query Optimization
    SELECT * FROM products WHERE name LIKE 'Laptop%'
    