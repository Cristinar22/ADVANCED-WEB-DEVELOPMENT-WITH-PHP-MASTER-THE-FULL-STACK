
    # Using FileZilla to connect and upload files
    # Drag and drop files from local machine to remote server
    