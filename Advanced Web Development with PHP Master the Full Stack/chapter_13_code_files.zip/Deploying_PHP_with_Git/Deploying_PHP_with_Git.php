
    # Setting up Git on the Server
    sudo apt-get update
    sudo apt-get install git
    # Cloning the repository
    git clone https://github.com/your-username/your-repository.git
    # Pushing code changes
    git add .
    git commit -m "Updated application"
    git push origin main
    # Pulling latest changes from Git
    cd /path/to/your/project
    git pull origin main
    